<header class="cabecera">
<?php include 'INCLUDES/redireccion.php';?>
<img src="img/logo.png">
<div class="bienvenida"><p><i class="fa fa-user-circle" aria-hidden="true"></i>
Bienvenido <?php echo $_SESSION['usuario']?></p>
<p><a href="index.php"><i class="fa fa-times-circle" aria-hidden="true">
Cerrar sesión</a></p></i></div>
</header>
