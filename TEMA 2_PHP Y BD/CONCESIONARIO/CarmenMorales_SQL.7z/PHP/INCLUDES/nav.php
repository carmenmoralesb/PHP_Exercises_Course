<nav class="navegacion">
<ul>
    <li><a href="listar_coches.php">Principal</a></li>
    <li><a href="listar_encargos.php">Listar encargos</a></li>
    <li><a href="insertar_coche.php">Añadir coches</a></li>
</ul> 
</nav>