<header class="cabecera">
<img src="img/logo.png">
</header>